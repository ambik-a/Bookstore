-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2022 at 10:31 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `xenonstack`
--

-- --------------------------------------------------------

--
-- Table structure for table `contactusquery`
--

CREATE TABLE `contactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `university` varchar(255) DEFAULT NULL,
  `coursewant` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contactusquery`
--

INSERT INTO `contactusquery` (`id`, `name`, `email`, `mobile`, `university`, `coursewant`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Abhishek', 'rishut195@gmail.com', '09816198077', 'chandigarh university', 'aa', 'A', '2022-10-19 19:35:08', '2022-10-19 19:35:08'),
(2, 'Abhishek', 'rishut195@gmail.com', '09816198077', 'chandigarh university', 'aa', 'A', '2022-10-19 19:36:35', '2022-10-19 19:36:35'),
(3, 'Neha kumari', 'thakurdbec@gmail.com', '08219744842', 'chandigarh university', 'aa', 'a', '2022-10-19 19:43:48', '2022-10-19 19:43:48'),
(4, 'Neha kumari', 'thakurdbec@gmail.com', '08219744842', 'chandigarh university', 'aa', 'a', '2022-10-19 19:45:30', '2022-10-19 19:45:30');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `status` varchar(2) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `mobile`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Peter', 'Parker', NULL, 'peterparker@mail.com', '0', '2022-10-19 18:18:48', '2022-10-19 18:18:48'),
(2, 'abc', 'email', 'password', 'mobile', '0', '2022-10-19 18:25:11', '2022-10-19 18:25:11'),
(3, 'Abhishek', 'rishut195@gmail.com', 'password', '09816198077', '0', '2022-10-19 18:25:52', '2022-10-19 18:25:52'),
(4, 'Abhishek', 'rishut195@gmail.com', 'sdf', '09816198077', '0', '2022-10-19 20:01:03', '2022-10-19 20:01:03'),
(5, 'Abhishek', 'rishut195@gmail.com', 'sdf', '09816198077', '0', '2022-10-19 20:02:11', '2022-10-19 20:02:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contactusquery`
--
ALTER TABLE `contactusquery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contactusquery`
--
ALTER TABLE `contactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
