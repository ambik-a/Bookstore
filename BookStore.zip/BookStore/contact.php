<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Book Store</title>
    <link
      rel="shortcut icon"
      type="image/x-icon"
      href="assets/apple-touch-icon.png"
    />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"
    />
  </head>
  <body>
    <!--Navbar Starts-->
    <nav class="navbar navbar-expand-lg">
      <div class="container-fluid">
        <a class="navbar-brand" href="index.php"
          ><img src="assets/booklogo.jpg" alt="" /><span class="s2">Book</span
          ><span class="s1">Store</span></a
        >
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            
          </ul>
          <form class="d-flex" role="search">
            <input
              class="form-control form1 me-2"
              type="search"
              placeholder="Search Books..."
              aria-label="Search"
            />
            <button class="btn btn2 btn-outline-success me-5" type="submit">
              <i class="fas fa-search"></i>
            </button>
          </form>
          <a href="login.php"
            ><button class="btn rounded-0 login me-5" type="submit">
              Login
            </button></a
          >
          <a href="signup.php"
            ><button class="btn login btn-outline-success me-5" type="submit">
              Register
            </button></a
          >
          <!--<button onclick="myFunction()">Toggle dark mode</button>-->
        </div>
      </div>
    </nav>
    <!--Navbar Ends-->

    <div class="container1">
      <div class="content">
        <div class="left-side">
          <div class="address details">
            <i class="fas fa-map-marker-alt"></i>
            <div class="topic">Address</div>
            <div class="text-one">
              A Block 10, 2nd Floor
            </div>
            <div class="text-two">
              Himachal
            </div>
          </div>
          <div class="phone details">
            <i class="fas fa-phone-alt"></i>
            <div class="topic">Phone</div>
            <div class="text-one">123456789</div>
          </div>
          <div class="email details">
            <i class="fas fa-envelope"></i>
            <div class="topic">Email</div>
            <div class="text-one">abc01@gmai.com</div>
          </div>
        </div>
        <div class="right-side">
          <div class="topic-text">Send us a message</div>
          <form action="contactcontroller.php" method="POST">
            <div class="input-box">
              <input type="text" placeholder="Enter your name" name="name"/>
            </div>
            <div class="input-box">
              <input type="text" placeholder="Enter your email" name= "email" />
            </div>
            <div class="input-box message-box">
              <textarea placeholder="Enter your message" name= "description"></textarea>
            </div>
            <div class="button">
              <input type="submit" value="Send Now"/>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!--Footer starts-->
    <footer>
      <div class="content">
        <div class="top">
          <div class="logo-details">
            <a class="navbar-brand" href="index.html"
              ><img
                src="assets/booklogo.jpg"
                alt=""
              /><span class="s2">Book</span><span class="s1">Store</span></a
            >
          </div>
          <div class="media-icons">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-linkedin-in"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
          </div>
        </div>
        <div class="link-boxes">
          <ul class="box">
            <li class="link_name">Company</li>
            <li><a href="index.html">Careers</a></li>
            <li><a href="aboutus.html">About us</a></li>
            <li><a href="contact.php">Contact us</a></li>
            <li><a href="index.html">Privacy Policy</a></li>
          </ul>
          <ul class="box">
            <li class="link_name">Account</li>
            <li><a href="#">Profile</a></li>
            <li><a href="#">My Account</a></li>
            <li><a href="#">Prefrences</a></li>
            <li><a href="#">Purchase</a></li>
          </ul>
          <ul class="box">
            <li class="link_name">Shop by category</li>
            <li><a href="#">Books</a></li>
            <li><a href="#">Fiction</a></li>
            <li><a href="#">Kids</a></li>
            <li><a href="#">eBooks</a></li>
          </ul>
          <ul class="box input-box">
            <li class="link_name">Subscribe</li>
            <li><input type="text" placeholder="Enter your email" /></li>
            <li><input type="button" value="Subscribe" /></li>
          </ul>
        </div>
      </div>
      <hr />
      <div class="bottom-details">
        <div class="bottom_text">
          <span class="copyright_text"
            >Copyright © 2022&nbsp;&nbsp; <a href="index.html">Book Store</a>All
            rights reserved</span
          >
          <span class="policy_terms">
            <a href="privacy.html">Privacy policy</a>
            <a href="terms_condition.html">Terms & condition</a>
          </span>
        </div>
      </div>
    </footer>

    <script src="assests/js/script.js"></script>
  </body>
</html>
