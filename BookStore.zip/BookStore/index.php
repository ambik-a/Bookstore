<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Book Store</title>
    <!-- Link Swiper's CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"
    />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"
    />
  </head>
  <body>
    <!--Navbar Starts-->
    <nav class="navbar navbar-expand-lg">
      <div class="container-fluid">
        <a class="navbar-brand" href="index.php"
          ><img src="assets/booklogo.jpg" alt="" /><span class="s2">Book</span
          ><span class="s1">Store</span></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul>
          <form class="d-flex" role="search">
            <input
              class="form-control rounded-0 form1 me-2"
              type="search"
              placeholder="Search for Books..."
              aria-label="Search"
            />
            <button class="btn btn2 rounded-0 me-5" type="submit">
              <i class="fas fa-search"></i>
            </button>
          </form>
          <a href="contact.php"
            ><button class="btn rounded-0 login me-5" type="submit">
              Contact us
            </button></a>
          <a href="login.php"
            ><button class="btn rounded-0 login me-5" type="submit">
              Login
            </button></a>
            <a href="signup.php"
            ><button class="btn rounded-0 login me-5" type="submit">
              Register
            </button></a>
            
          <!--<button onclick="myFunction()">Toggle dark mode</button>-->
        </div>
      </div>
    </nav>
    <!--Navbar Ends-->

    <div class="img-slider">
      <div class="slide active">
        <img src="assets/bookslider.jpg" alt="" />
        <div class="info">
          <h2>Books & Fictions</h2>
          <p>Reader lives a thousand lives before he dies</p>
        </div>
      </div>
       
      <div class="navigation">
        <div class="btn active"></div>
        <div class="btn"></div>
        <div class="btn"></div>
      </div>
    </div>

     

    <br />
    <div class="demand">
      <h2>Books</h2>
    </div>
    <!-- Swiper -->
    <div class="swiper mySwiper">
      <div class="swiper-wrapper">
         
        <div class="swiper-slide">
          <img src="assets/book1.jpeg" alt="img" />
          <span class="discount-tag">15% off</span>
          <div class="info1">
            <h3>Books</h3>
            <p>Delhi NCR</p>
            <h6>Price: <span class="duration">300</span> Rs</h6>
            <a href="#">Know More</a>
          </div>
        </div>
        <div class="swiper-slide">
          <img src="assets/book2.jpeg" alt="img" />
          <span class="discount-tag">10% off</span>
          <div class="info1">
            <h3>Fiction</h3>
            <p>Near Gateway of India, Mumbai</p>
            <h6>Price: <span class="duration">1400</span> Rs</h6>
            <a href="#">Know More</a>
          </div>
        </div>
        <div class="swiper-slide">
          <img src="assets/book3.jpg" alt="img" />
          <span class="discount-tag">10% off</span>
          <div class="info1">
            <h3>Kids Books</h3>
            <p>Church Street, Bengaluru </p>
            <h6>Price: <span class="duration">200</span> RS</h6>
            <a href="#">Know More</a>
          </div>
        </div>
      </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
      <div class="swiper-pagination"></div>
    </div>

    <!--Footer starts-->
    <footer>
      <div class="content">
        <div class="top">
          <div class="logo-details">
            <a class="navbar-brand" href="index.php"
              ><img src="assets/booklogo.jpg" alt="" /><span
                class="s2"
                >Book</span
              ><span class="s1"> Store</span></a
            >
          </div>
          <div class="media-icons">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-linkedin-in"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
          </div>
        </div>
        <div class="link-boxes">
          <ul class="box">
            <li class="link_name">Company</li>
            <li><a href="index.html">Careers</a></li>
            <li><a href="aboutus.html">About us</a></li>
            <li><a href="contact.php">Contact us</a></li>
            <li><a href="index.html">Privacy Policy</a></li>
          </ul>
          <ul class="box">
            <li class="link_name">Account</li>
            <li><a href="#">Profile</a></li>
            <li><a href="#">My Account</a></li>
            <li><a href="#">Prefrences</a></li>
            <li><a href="#">Purchase</a></li>
          </ul>
          <ul class="box">
            <li class="link_name">Shop by category</li>
            <li><a href="#">Books</a></li>
            <li><a href="#">Fiction</a></li>
            <li><a href="#">Kids</a></li>
            <li><a href="#">eBooks</a></li>
          </ul>
           
          <ul class="box input-box">
            <li class="link_name">Subscribe</li>
            <li><input type="text" placeholder="Enter your email" /></li>
            <li><input type="button" value="Subscribe" /></li>
          </ul>
        </div>
      </div>
      <hr />
      <div class="bottom-details">
        <div class="bottom_text">
          <span class="copyright_text"
            >Copyright © 2022&nbsp;&nbsp; <a href="index.html">Book Store</a>All
            rights reserved</span
          >
          <span class="policy_terms">
            <a href="privacy.html">Privacy policy</a>
            <a href="terms_condition.html">Terms & condition</a>
          </span>
        </div>
      </div>
    </footer>

    
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

    <script>
      var swiper = new Swiper(".mySwiper", {
        slidesPerView: "auto",
        spaceBetween: 40,
        centeredSlides: true,
        grabCursor: true,
        loop: true,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
      });
    </script>

    <script src="assets/js/script.js"></script>
  </body>
</html>
